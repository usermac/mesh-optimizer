use anyhow::{Context, Result}; // Added Context for better errors
use clap::Parser;
use meshopt::VertexDataAdapter;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to the input .obj file
    #[arg(short, long)]
    input: PathBuf,

    /// Path to the output .obj file
    #[arg(short, long)]
    output: PathBuf,

    /// Target triangle count ratio (0.0 to 1.0)
    #[arg(short, long, default_value_t = 0.5)]
    ratio: f32,
}

fn main() -> Result<()> {
    let args = Args::parse();
    println!("Loading model: {:?}", args.input);

    // 1. Load the OBJ file
    let (models, _) = tobj::load_obj(
        &args.input,
        &tobj::LoadOptions {
            single_index: true,
            triangulate: true,
            ..Default::default()
        },
    )
    .context("Failed to load OBJ file")?;

    // Check if file is empty
    if models.is_empty() {
        return Err(anyhow::anyhow!("No models found in the OBJ file"));
    }

    let mesh = &models[0].mesh;
    let positions = &mesh.positions;
    let indices = &mesh.indices;

    println!(
        "Original: {} indices, {} vertices",
        indices.len(),
        positions.len() / 3
    );

    // 2. Perform Decimation (The Math)
    let target_count = (indices.len() as f32 * args.ratio) as usize;

    // Convert Vec<f32> to raw bytes &[u8] safely
    let vertex_data_u8 = bytemuck::cast_slice(positions);

    // Create the adapter.
    // We use .map_err here because meshopt errors don't convert automatically
    let adapter = VertexDataAdapter::new(vertex_data_u8, 12, 0)
        .map_err(|e| anyhow::anyhow!("Failed to create vertex adapter: {:?}", e))?;

    let simplified_indices = meshopt::simplify(
        indices,      // Original Indices
        &adapter,     // Adapter
        target_count, // Target count
        0.01,         // Error tolerance
    );

    println!(
        "Optimized: {} indices ({}%)",
        simplified_indices.len(),
        (simplified_indices.len() as f32 / indices.len() as f32) * 100.0
    );

    // 3. Write Output
    save_obj(&args.output, positions, &simplified_indices)?;

    println!("Saved to {:?}", args.output);
    Ok(())
}

fn save_obj(path: &PathBuf, positions: &[f32], indices: &[u32]) -> Result<()> {
    let mut file = File::create(path).context("Failed to create output file")?;

    for chunk in positions.chunks(3) {
        writeln!(file, "v {} {} {}", chunk[0], chunk[1], chunk[2])?;
    }

    for chunk in indices.chunks(3) {
        writeln!(file, "f {} {} {}", chunk[0] + 1, chunk[1] + 1, chunk[2] + 1)?;
    }

    Ok(())
}
// 2025-12-01 - To run a test d/l the next line and then run the cargo. - Brian
// 2025-12-01 - curl -L -o walt.obj https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/obj/walt/WaltHead.obj
// 2025-12-01 - cargo run -- --input bunny.obj --output bunny_optimized.obj --ratio 0.5
